var _aspect_ratio_manager_type_8cs =
[
    [ "AspectRatioManagerType", "_aspect_ratio_manager_type_8cs.html#a835951be970d9728237b91434590f128", [
      [ "Client", "_aspect_ratio_manager_type_8cs.html#a835951be970d9728237b91434590f128a577d7068826de925ea2aec01dbadf5e4", null ],
      [ "Reference", "_aspect_ratio_manager_type_8cs.html#a835951be970d9728237b91434590f128a63d5049791d9d79d86e9a108b0a999ca", null ]
    ] ]
];