var _file_locations_8cs =
[
    [ "FileLocations", "_file_locations_8cs.html#a14a9baf701f5f0f791ef023f83a50b1d", [
      [ "Custom", "_file_locations_8cs.html#a14a9baf701f5f0f791ef023f83a50b1da90589c47f06eb971d548591f23c285af", null ],
      [ "DriveRoot", "_file_locations_8cs.html#a14a9baf701f5f0f791ef023f83a50b1dabfb26313c53da953f3943b515f18bb88", null ],
      [ "Desktop", "_file_locations_8cs.html#a14a9baf701f5f0f791ef023f83a50b1da2310408a63388fe57e3a4177168a8798", null ],
      [ "Documents", "_file_locations_8cs.html#a14a9baf701f5f0f791ef023f83a50b1daf28128b38efbc6134dc40751ee21fd29", null ],
      [ "Users", "_file_locations_8cs.html#a14a9baf701f5f0f791ef023f83a50b1daf9aae5fda8d810a29f12d1e61b4ab25f", null ],
      [ "ActiveUser", "_file_locations_8cs.html#a14a9baf701f5f0f791ef023f83a50b1dafe44721528769a4541a0a1774371bc19", null ],
      [ "DataPath", "_file_locations_8cs.html#a14a9baf701f5f0f791ef023f83a50b1da4ace5426e051f5deae509b9d4333f01c", null ],
      [ "PersistentDataPath", "_file_locations_8cs.html#a14a9baf701f5f0f791ef023f83a50b1daa719b7977a39d032029f3567d4499e0b", null ],
      [ "StreamingAssets", "_file_locations_8cs.html#a14a9baf701f5f0f791ef023f83a50b1da0b38d14680695e16fe6e41b1959921d0", null ]
    ] ]
];