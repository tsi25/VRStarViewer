var _actor_type_8cs =
[
    [ "ActorType", "_actor_type_8cs.html#ab4dedbdc242d83110c014709467efb48", [
      [ "None", "_actor_type_8cs.html#ab4dedbdc242d83110c014709467efb48a6adf97f83acf6453d4a6a4b1070f3754", null ],
      [ "Ally", "_actor_type_8cs.html#ab4dedbdc242d83110c014709467efb48a0dd87782600574e2f791bcfe639d4fcc", null ],
      [ "Neutral", "_actor_type_8cs.html#ab4dedbdc242d83110c014709467efb48ae9bb5320b3890b6747c91b5a71ae5a01", null ],
      [ "Enemy", "_actor_type_8cs.html#ab4dedbdc242d83110c014709467efb48a8c6d21187fb58b7a079d70030686b33e", null ]
    ] ]
];