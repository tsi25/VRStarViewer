var _camera_id_8cs =
[
    [ "CameraId", "_camera_id_8cs.html#aff18b5ad927dd111194c46e9ccdaf98e", [
      [ "None", "_camera_id_8cs.html#aff18b5ad927dd111194c46e9ccdaf98ea6adf97f83acf6453d4a6a4b1070f3754", null ],
      [ "Main", "_camera_id_8cs.html#aff18b5ad927dd111194c46e9ccdaf98eaa02c83a7dbd96295beaefb72c2bee2de", null ],
      [ "UI2D", "_camera_id_8cs.html#aff18b5ad927dd111194c46e9ccdaf98ea186f1ad3eca3fe05fa67c36259b83c01", null ],
      [ "UI3D", "_camera_id_8cs.html#aff18b5ad927dd111194c46e9ccdaf98ea6b590909d176d6d4b0e1916e660dbc16", null ]
    ] ]
];