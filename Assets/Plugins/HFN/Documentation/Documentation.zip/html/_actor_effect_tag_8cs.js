var _actor_effect_tag_8cs =
[
    [ "ActorEffectTag", "_actor_effect_tag_8cs.html#a3d0f347de9174b96c9922550a123f082", [
      [ "All", "_actor_effect_tag_8cs.html#a3d0f347de9174b96c9922550a123f082ab1c94ca2fbc3e78fc30069c8d0f01680", null ],
      [ "None", "_actor_effect_tag_8cs.html#a3d0f347de9174b96c9922550a123f082a6adf97f83acf6453d4a6a4b1070f3754", null ],
      [ "Leech", "_actor_effect_tag_8cs.html#a3d0f347de9174b96c9922550a123f082a3ae3b8b59e7688e09320f3081ed966b2", null ],
      [ "Stun", "_actor_effect_tag_8cs.html#a3d0f347de9174b96c9922550a123f082a27e9c0d7972e999a5bbe094c4cede584", null ],
      [ "Rend", "_actor_effect_tag_8cs.html#a3d0f347de9174b96c9922550a123f082a0b908b09defeceed7fde911d2645c716", null ],
      [ "Burn", "_actor_effect_tag_8cs.html#a3d0f347de9174b96c9922550a123f082a11635778f116ce6922f6068638a39028", null ],
      [ "Heal", "_actor_effect_tag_8cs.html#a3d0f347de9174b96c9922550a123f082af357105e6becc3076a3da9b43465051a", null ],
      [ "Poison", "_actor_effect_tag_8cs.html#a3d0f347de9174b96c9922550a123f082a3a9d1818d0d7f5646e63465baf7d366f", null ],
      [ "Slow", "_actor_effect_tag_8cs.html#a3d0f347de9174b96c9922550a123f082aefa5397985b8609a5dbeb430a4bcadd3", null ],
      [ "Corrode", "_actor_effect_tag_8cs.html#a3d0f347de9174b96c9922550a123f082af409708871cd21859a90eae4a255bb22", null ],
      [ "Drain", "_actor_effect_tag_8cs.html#a3d0f347de9174b96c9922550a123f082a0e37f13157f126473ed9ea7b244fca4c", null ],
      [ "Cold", "_actor_effect_tag_8cs.html#a3d0f347de9174b96c9922550a123f082a1a3c2e99e572ec71d3820d0363d90742", null ],
      [ "Shock", "_actor_effect_tag_8cs.html#a3d0f347de9174b96c9922550a123f082a6d94cc3f12ed48367e35cd9f9e2dc781", null ],
      [ "Damage", "_actor_effect_tag_8cs.html#a3d0f347de9174b96c9922550a123f082ab9f24e83531326204197015b2f43a93f", null ]
    ] ]
];