var _drag_confinement_type_8cs =
[
    [ "DragConfinementType", "_drag_confinement_type_8cs.html#a869a3e9aae32e080db2bfac385ac613f", [
      [ "None", "_drag_confinement_type_8cs.html#a869a3e9aae32e080db2bfac385ac613fa6adf97f83acf6453d4a6a4b1070f3754", null ],
      [ "ConfineToParent", "_drag_confinement_type_8cs.html#a869a3e9aae32e080db2bfac385ac613fa7ce28a5640663804a055607e545822d5", null ],
      [ "ConfineToRegion", "_drag_confinement_type_8cs.html#a869a3e9aae32e080db2bfac385ac613fa0924e7e9b6001beb8fc165b9ee46ac08", null ]
    ] ]
];