var _drop_tag_8cs =
[
    [ "DropTag", "_drop_tag_8cs.html#a3264db1d5c177cd18f58b384c1d9530b", [
      [ "None", "_drop_tag_8cs.html#a3264db1d5c177cd18f58b384c1d9530ba6adf97f83acf6453d4a6a4b1070f3754", null ],
      [ "Durability", "_drop_tag_8cs.html#a3264db1d5c177cd18f58b384c1d9530ba2166e76dc88d642260416a536b06a412", null ]
    ] ]
];