var _clip_start_value_type_8cs =
[
    [ "ClipStartValueType", "_clip_start_value_type_8cs.html#a638fb654674eb13585637d187e7f9c14", [
      [ "Custom", "_clip_start_value_type_8cs.html#a638fb654674eb13585637d187e7f9c14a90589c47f06eb971d548591f23c285af", null ],
      [ "AsIs", "_clip_start_value_type_8cs.html#a638fb654674eb13585637d187e7f9c14a2a299b97d622f2c29576b3bc2c709db0", null ]
    ] ]
];