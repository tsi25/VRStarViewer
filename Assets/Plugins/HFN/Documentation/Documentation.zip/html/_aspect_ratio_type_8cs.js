var _aspect_ratio_type_8cs =
[
    [ "AspectRatioType", "_aspect_ratio_type_8cs.html#aed2ce5b2135f1a0a5c4c38987a4a1388", [
      [ "Custom", "_aspect_ratio_type_8cs.html#aed2ce5b2135f1a0a5c4c38987a4a1388a90589c47f06eb971d548591f23c285af", null ],
      [ "_5x4", "_aspect_ratio_type_8cs.html#aed2ce5b2135f1a0a5c4c38987a4a1388a55bc5b076ccb77a74cfc72ca3442b8a4", null ],
      [ "_4x3", "_aspect_ratio_type_8cs.html#aed2ce5b2135f1a0a5c4c38987a4a1388a4c8ab86ea3e82d16f8d02c2c79dcd028", null ],
      [ "_3x2", "_aspect_ratio_type_8cs.html#aed2ce5b2135f1a0a5c4c38987a4a1388a16e4a3cd255aa127a724b8b8c5eacfae", null ],
      [ "_16x10", "_aspect_ratio_type_8cs.html#aed2ce5b2135f1a0a5c4c38987a4a1388afb512cea2973dd3270ffcdfb5c380ab6", null ],
      [ "_16x9", "_aspect_ratio_type_8cs.html#aed2ce5b2135f1a0a5c4c38987a4a1388adf34a66236c63ba1f347b377e9a9d7ec", null ],
      [ "_4x5", "_aspect_ratio_type_8cs.html#aed2ce5b2135f1a0a5c4c38987a4a1388a84ad13d9c5326a3de42e1987b76a2dd1", null ],
      [ "_3x4", "_aspect_ratio_type_8cs.html#aed2ce5b2135f1a0a5c4c38987a4a1388aed2820d1209524a5fea23355df5e9f78", null ],
      [ "_2x3", "_aspect_ratio_type_8cs.html#aed2ce5b2135f1a0a5c4c38987a4a1388a9c2c33adbbf5be229fee9adb7b1af1d3", null ],
      [ "_10x16", "_aspect_ratio_type_8cs.html#aed2ce5b2135f1a0a5c4c38987a4a1388a26c407806feac5e7516fb97678bb2d21", null ],
      [ "_9x16", "_aspect_ratio_type_8cs.html#aed2ce5b2135f1a0a5c4c38987a4a1388ac025a47193fcf82f1de982fb6dcfe37d", null ]
    ] ]
];