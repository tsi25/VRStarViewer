var _asset_g_u_i_d_type_8cs =
[
    [ "AssetGUIDType", "_asset_g_u_i_d_type_8cs.html#a06934eabcd4e0309fe39b8a5ba998cc7", [
      [ "Reference", "_asset_g_u_i_d_type_8cs.html#a06934eabcd4e0309fe39b8a5ba998cc7a63d5049791d9d79d86e9a108b0a999ca", null ],
      [ "String", "_asset_g_u_i_d_type_8cs.html#a06934eabcd4e0309fe39b8a5ba998cc7a27118326006d3829667a400ad23d5d98", null ]
    ] ]
];